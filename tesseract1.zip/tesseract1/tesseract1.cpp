﻿// tesseract1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
#include <iostream>
#include <tesseract/baseapi.h>
#include <leptonica/allheaders.h>
#include <Windows.h>
#include<opencv2/opencv.hpp>

int main()
{
	char* outText;

	tesseract::TessBaseAPI* api = new tesseract::TessBaseAPI();
	// Initialize tesseract-ocr with English, without specifying tessdata path
	if (api->Init(".\\tessdata", "rus")) {
		fprintf(stderr, "Could not initialize tesseract.\n");
		exit(1);
	}

	//первые две итерации только тисиракт без использования опенсиви
	const char* pics[] = { ".\\file1.png", ".\\file1fch.png", ".\\file1.png" };
	
	for (int i = 0; i < (sizeof(pics) / sizeof(const char*)); i++) {
		// Open input image with leptonica library
		Pix* image = pixRead(pics[i]);
		if (i == 2) {
			api->SetVariable("user_defined_dpi", "96"); //Warning: Invalid resolution 0 dpi. Using 70 instead.
			api->SetPageSegMode(tesseract::PSM_SINGLE_CHAR);
			cv::Mat img = cv::imread(pics[i], -1);
			cv::Mat sub = img(cv::Rect(47, 144, 46 / 3, 20));
			api->SetImage((uchar*)sub.data, sub.size().width, sub.size().height, sub.channels(), sub.step1());
			api->Recognize(0);
		}
		else {
			api->SetImage(image);
		}
		// Get OCR result
		outText = api->GetUTF8Text();
		// convert multibyte UTF-8 to wide string UTF-16
		int length = MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)outText, -1, NULL, 0);
		if (length > 0)
		{
			wchar_t* wide = new wchar_t[length];
			MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)outText, -1, wide, length);

			// convert it to ANSI
			char* ansi = new char[length];
			WideCharToMultiByte(CP_ACP, 0, wide, -1, ansi, length, NULL, NULL);
			printf("%u - OCR output ANSI:\n%s", i, ansi); // раньше фар работал в 1251, а тут смотрю 866
			WideCharToMultiByte(CP_OEMCP, 0, wide, -1, ansi, length, NULL, NULL);
			printf("%u - OCR output OEM:\n%s", i, ansi);
			delete[] wide;
			delete[] ansi;
		}
		printf("%u - OCR output UTF-8:\n%s", i, outText);

		// Destroy used object and release memory
		delete[] outText;
		pixDestroy(&image);
	}

	api->End();

	return 0;
}